<?php
/**
Template Name: Option Theme
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

get_header();
?>
<div class="container">
		<div id="primary">
			<div id="content" role="main">

				<article id="post-0" class="post no-results not-found">
					<header class="entry-header">
						<h1 class="entry-title">Options Check</h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
						 <h2>Basic Options</h2>
                        
                        <dl>
                        <dt>type: text (mini)</dt>
                        <dd><?php echo of_get_option('example_text_mini', 'no entry'); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: text</dt>
                        <dd><?php echo of_get_option('example_text', 'no entry'); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: textarea</dt>
                        <dd><?php echo of_get_option('example_textarea', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: select (mini)</dt>
                        <dd><?php echo of_get_option('example_select', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: select2 (wide)</dt>
                        <dd><?php echo of_get_option('example_select_wide', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: select</dt>
                        <dd><?php echo of_get_option('example_select_categories', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: select</dt>
                        <dd><?php echo of_get_option('example_select_pages', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: radio</dt>
                        <dd><?php echo of_get_option('example_radio', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: checkbox</dt>
                        <dd><?php echo of_get_option('example_checkbox', 'no entry' ); ?></dd>
                        </dl>
                        
                        <hr/>
                        
                        <h2>Advanced Options</h2>
                        
                        <dl>
                        <dt>type: uploader</dt>
                        <dd><?php echo of_get_option('example_uploader', 'no entry'); ?></dd>
                        <?php if ( of_get_option('example_uploader') ) { ?>
                        <img src="<?php echo of_get_option('example_uploader'); ?>" />
                        <?php } ?>
                        </dl>
                        
                        <dl>
                        <dt>type: image</dt>
                        <dd><?php echo of_get_option('example_images', 'no entry' ); ?></dd>
                        </dl>
                        
                        <dl>
                        <dt>type: multicheck</dt>
                        <dd>
                        <?php $multicheck = of_get_option('example_multicheck', 'none' ); ?>
                        <?php print_r($multicheck); ?>
                        </dd>
                        </dl>
                        
                        <p>The array sent in the options panel was defined as:<br>
                        <?php
                        $test_array_jr = array("one" => "French Toast","two" => "Pancake","three" => "Omelette","four" => "Crepe","five" => "Waffle"); 
                        print_r($test_array_jr);
                        ?>
                        </p>
                        
                        <p>You can get the value of all items in the checkbox array:</p>
                        <ul>
                        <?php
                        if ( is_array($multicheck) ) {
                            foreach ($multicheck as $key => $value) {
                                // If you need the option's name rather than the key you can get that
                                $name = $test_array_jr[$key];
                                // Prints out each of the values
                                echo '<li>' . $key . ' (' . $name . ') = ' . $value . '</li>';
                            }
                        }
                        else {
                            echo '<li>There are no saved values yet.</li>';
                        }
                        ?>
                        </ul>
                        
                        <?php
                        if (isset($multicheck['one']) ) {
                            echo $multicheck['one'];
                        } else {
                            echo 'no entry';
                        }
                        ?>
                        </b>
                        </p>
                        
                        
                        <dl>
                        <dt>type: background</dt>
                        <?php $background = of_get_option('example_background');
                        if ($background) {
                            if ($background['image']) {
                                echo '<span style="display: block; height: 200px; width: 200px; background:url('.$background['image']. ') "></span>';
                                echo '<ul>';
                                foreach ($background as $i=>$param){
                                    echo '<li>'.$i . ' = ' . $param.'</li>';
                            }
                            echo '</ul>';
                            } else {
                                echo '<span style="display: inline-block; height: 20px; width: 20px; background:'.$background['color']. ' "></span>';
                                echo '<ul>';
                                echo '<li>'.$background['color'].'</li>';
                                echo '</ul>';
                            }	
                        } else {
                            echo "no entry";
                        }; ?>
                        </span>
                        </dd>
                        </dl>
                        
                        <dl>
                        <dt>type: colorpicker</dt>
                        <dd>
                        <span style="color:<?php echo of_get_option('example_colorpicker', '#000' ); ?>">
                        <?php echo of_get_option('example_colorpicker', 'no entry' ); ?>
                        </span>
                        </dd>
                        </dl>
                        
                        <dl>
                        <dt>type: typography</dt>
                        <dd>
                        <?php $typography = of_get_option('example_typography');
                        if ($typography) {
                            echo '<span style="font:'.$typography['size'] . ' ' . $typography['face']. ' ' . $typography['style'] . '; color:'.$typography['color'].';">Some sample text in your style</span>';
                            
                            echo '<ul>';
                            foreach ($typography as $i=>$param) {
                                echo '<li>'.$i . ' = ' . $param.'</li>';
                            }
                                echo '</ul>';
                        } else {
                            echo "no entry";
                        } ?>
                        </dd>
                        </dl>
            
					</div><!-- .entry-content -->
				</article><!-- #post-0 -->


			</div><!-- #content -->
		</div><!-- #primary -->
</dd>
<?php get_footer(); ?>

